# Netflix_R_visualization.R
# This R script reads the cleaned Netflix dataset and visualizes the ratings distribution.
# Ensure that "Netflix_shows_movies_cleaned.csv" is in your working directory.

# Load necessary library
library(ggplot2)

# Read the cleaned CSV file into an R data frame
Netflix_shows_movies <- read.csv("Netflix_shows_movies_cleaned.csv", stringsAsFactors = FALSE)

# Create a bar plot for the ratings distribution
ratings_plot <- ggplot(Netflix_shows_movies, aes(x = rating)) +
  geom_bar(fill = "steelblue") +
  theme_minimal() +
  labs(title = "Ratings Distribution", x = "Rating", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Display the plot in the R console
print(ratings_plot)

# Optional: Save the plot as an image file (e.g., PNG)
ggsave("ratings_distribution.png", plot = ratings_plot, width = 8, height = 6)
